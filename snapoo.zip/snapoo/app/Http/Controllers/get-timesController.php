<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class get-timesController extends Controller
{
    //
}
