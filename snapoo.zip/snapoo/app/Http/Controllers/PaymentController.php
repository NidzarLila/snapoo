<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Midtrans\Snap;
use Midtrans\Config;

class MidtransController extends Controller
{
    public function __construct()
    {
        // Atur kredensial Midtrans
        Config::$serverKey = env('MIDTRANS_SERVER_KEY');
        Config::$isProduction = env('MIDTRANS_IS_PRODUCTION');
        Config::$isSanitized = true;
        Config::$is3ds = true;
    }

    public function payment(Request $request)
    {
        // Buat transaksi baru di Midtrans
        $transactionParams = [
            'transaction_details' => [
                'order_id' => 'ORDER-' . time(),
                'gross_amount' => $request->subtotal,
            ],
            'customer_details' => [
                'first_name' => $request->nama,
                'email' => $request->email,
                'phone' => $request->no_hp,
            ],
            'item_details' => [
                [
                    'id' => 'PROD-' . time(),
                    'price' => $request->subtotal,
                    'quantity' => 1,
                    'name' => $request->nama_paket,
                ],
            ],
        ];

        // Dapatkan token pembayaran dari Midtrans
        $snapToken = Snap::getSnapToken($transactionParams);

        // Kembalikan token ke halaman pembayaran
        return view('midtrans.payment', compact('snapToken'));
    }
}
