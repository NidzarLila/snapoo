<?php

namespace App\Http\Controllers;

use App\Models\Reservasi;
use Illuminate\Http\Request;

class RiwayatTransaksiController extends Controller
{
    public function index()
    {
         // Mengambil riwayat reservasi yang terkait dengan pengguna yang login
     $reservationHistory = Reservasi::where('nama', auth()->user()->nama)->get();
     return view('user.history', compact('reservationHistory'));
    }
    
   
}
