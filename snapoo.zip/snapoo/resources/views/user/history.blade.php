@extends('layouts.user.app')
@section('contents')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Riwayat Transaksi</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID Transaksi</th>
                            <th>Nama Pembeli</th>
                            <th>Nama Paket</th>
                            <th>Tanggal</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($reservationHistory as $transaction)
                            <tr>
                                <td>{{ $transaction->id_reservasi }}</td>
                                <td>{{ $transaction->nama }}</td>
                                <td>{{ $transaction->nama_paket }}</td>
                                <td>{{ $transaction->tanggal }}</td>
                                <td>{{ $transaction->subtotal }}</td>
                                <td>{{ $transaction->status }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

