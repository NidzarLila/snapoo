
<?php $__env->startSection('contents'); ?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <?php if(session()->has('pesan')): ?>
            <!-- Tampilkan pesan session dalam bentuk Toastr saat dokumen dimuat -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Panggil metode Toastr
                    toastr.success("<?php echo e(session('pesan')); ?>");
                });
            </script>
            <?php endif; ?>
            <?php if(session()->has('hapus')): ?>
            <!-- Tampilkan pesan session dalam bentuk Toastr saat dokumen dimuat -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Panggil metode Toastr
                    toastr.warning("<?php echo e(session('hapus')); ?>");
                });
            </script>
            <?php endif; ?>
            <strong class="card-title">Data pelanggan</strong>
            <div class="col-auto">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahModal">
                    Tambah Data Pelanggan
                </button>
                <a href="<?php echo e(url('services/tambah')); ?>" class="btn btn-primary my-3">Tambah Data Services Extra</a>
                <a href="/pelanggan/exportexcel" class="btn btn-primary my-3" target="_blank">Download File Excel</a>
                <a href="/pelanggan/importexcel" class="btn btn-secondary my-3" data-toggle="modal" data-target="#exampleModal">Upload Data Pelanggan</a>
                <a href="/pelanggan/exportpdf" class="btn btn-info my-3" target="_blank">Download File PDF</a>
            </div>
        </div>

        <div class="table-responsive">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Nama</th>
                        <th>Paket</th>
                        <th>Person</th>
                        <th>Basic Frame</th>
                        <th>Special Frame</th>
                        <th>Instax</th>
                        <th>Projector</th>
                        <th>Custom image</th>
                        <th>A4</th>
                        <th>Pet</th>
                        <th>Lovers Flowers</th>
                        <th>Shift</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($pelanggan->tanggal); ?></td>
                        <td><?php echo e($pelanggan->jam); ?></td>
                        <td><?php echo e($pelanggan->nama); ?></td>
                        <td><?php echo e($pelanggan->nama_paket); ?></td>
                        <td><?php echo e($pelanggan->person); ?></td>
                        <td><?php echo e($pelanggan->basic_frame); ?></td>
                        <td><?php echo e($pelanggan->special_frame); ?></td>
                        <td><?php echo e($pelanggan->instax); ?></td>
                        <td><?php echo e($pelanggan->projector); ?></td>
                        <td><?php echo e($pelanggan->custom_image); ?></td>
                        <td><?php echo e($pelanggan->a4); ?></td>
                        <td><?php echo e($pelanggan->pet); ?></td>
                        <td><?php echo e($pelanggan->lover_flower); ?></td>
                        <td><?php echo e($pelanggan->shift); ?></td>
                        <td><?php echo e($pelanggan->keterangan); ?></td>
                        <td>
                            <button type="button" class="btn btn-primary edit-btn" data-toggle="modal" data-target="#editModal" data-id="<?php echo e($pelanggan->id_pelanggan); ?>">Edit</button>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- Modal -->
            <div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pelanggan</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <!-- Formulir Tambah Data Pelanggan -->
                            <form action="<?php echo e(url('services/tambah')); ?>" method="POST">
                                <?php echo csrf_field(); ?> <!-- Untuk proteksi CSRF -->

                                <div class="form-group">
                                    <label for="tanggal">Tanggal</label>
                                    <input type="text" class="form-control" id="tanggal" name="tanggal">
                                </div>

                                <div class="form-group">
                                    <label for="jam">Jam</label>
                                    <input type="text" class="form-control" id="jam" name="jam">
                                </div>

                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <select class="form-control" id="nama" name="nama">
                                        <!-- Opsi default untuk memilih -->
                                        <option value="">Pilih Nama</option>
                                        <!-- Loop untuk menampilkan nama dari tabel reservasi -->
                                        <?php $__currentLoopData = $reservasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reservasi->nama); ?>"><?php echo e($reservasi->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>



                                <div class="form-group">
                                    <label for="nama_paket">Paket</label>
                                    <input type="text" class="form-control" id="nama_paket" name="nama_paket">
                                </div>

                                <div class="form-group">
                                    <label for="person">Person</label>
                                    <input type="text" class="form-control" id="person" name="person">
                                </div>

                                <div class="form-group">
                                    <label for="basic_frame">Basic Frame</label>
                                    <input type="text" class="form-control" id="basic_frame" name="basic_frame">
                                </div>

                                <div class="form-group">
                                    <label for="special_frame">Special Frame</label>
                                    <input type="text" class="form-control" id="special_frame" name="special_frame">
                                </div>

                                <div class="form-group">
                                    <label for="instax">Instax</label>
                                    <input type="text" class="form-control" id="instax" name="instax">
                                </div>

                                <div class="form-group">
                                    <label for="projector">Projector</label>
                                    <input type="text" class="form-control" id="projector" name="projector">
                                </div>

                                <div class="form-group">
                                    <label for="custom_image">Custom Image</label>
                                    <input type="text" class="form-control" id="custom_image" name="custom_image">
                                </div>

                                <div class="form-group">
                                    <label for="a4">A4</label>
                                    <input type="text" class="form-control" id="a4" name="a4">
                                </div>

                                <div class="form-group">
                                    <label for="pet">Pet</label>
                                    <input type="text" class="form-control" id="pet" name="pet">
                                </div>

                                <div class="form-group">
                                    <label for="lovers_flowers">Lovers Flowers</label>
                                    <input type="text" class="form-control" id="lovers_flowers" name="lovers_flowers">
                                </div>

                                <div class="form-group">
                                    <label for="shift<?php echo e($pelanggan->id); ?>">Shift</label>
                                    <select class="form-control" id="shift<?php echo e($pelanggan->id); ?>" name="shift">
                                        <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($shift->id); ?>" <?php echo e($pelanggan->shift_id == $shift->id ? 'selected' : ''); ?>><?php echo e($shift->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="keterangan">Keterangan</label>
                                    <input type="text" class="form-control" id="keterangan" name="keterangan">
                                </div>

                                <!-- Tombol Submit -->
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal Edit -->
            <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit pelanggan</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <!-- Formulir Pengeditan -->
                            <form id="editForm">
                                <!-- Isi formulir di sini -->
                                <!-- Contoh: -->
                                <div class="form-group">
                                    <label for="tanggal<?php echo e($pelanggan->id); ?>">Tanggal</label>
                                    <input type="text" class="form-control" id="tanggal<?php echo e($pelanggan->id); ?>" name="tanggal" value="<?php echo e($pelanggan->tanggal); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="jam<?php echo e($pelanggan->id); ?>">Jam</label>
                                    <input type="text" class="form-control" id="jam<?php echo e($pelanggan->id); ?>" name="jam" value="<?php echo e($pelanggan->jam); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama<?php echo e($pelanggan->id); ?>">Nama</label>
                                    <input type="text" class="form-control" id="nama<?php echo e($pelanggan->id); ?>" name="nama" value="<?php echo e($pelanggan->nama); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama_paket<?php echo e($pelanggan->id); ?>">Paket</label>
                                    <input type="text" class="form-control" id="nama_paket<?php echo e($pelanggan->id); ?>" name="nama_paket" value="<?php echo e($pelanggan->nama_paket); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="person<?php echo e($pelanggan->id); ?>">Person</label>
                                    <input type="text" class="form-control" id="person<?php echo e($pelanggan->id); ?>" name="person" value="<?php echo e($pelanggan->person); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="basic_frame<?php echo e($pelanggan->id); ?>">Basic Frame</label>
                                    <input type="text" class="form-control" id="basic_frame<?php echo e($pelanggan->id); ?>" name="basic_frame" value="<?php echo e($pelanggan->basic_frame); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="special_frame<?php echo e($pelanggan->id); ?>">Special Frame</label>
                                    <input type="text" class="form-control" id="special_frame<?php echo e($pelanggan->id); ?>" name="special_frame" value="<?php echo e($pelanggan->special_frame); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="instax<?php echo e($pelanggan->id); ?>">Instax</label>
                                    <input type="text" class="form-control" id="instax<?php echo e($pelanggan->id); ?>" name="instax" value="<?php echo e($pelanggan->instax); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="projector<?php echo e($pelanggan->id); ?>">Projector</label>
                                    <input type="text" class="form-control" id="projector<?php echo e($pelanggan->id); ?>" name="projector" value="<?php echo e($pelanggan->projector); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="custom_image<?php echo e($pelanggan->id); ?>">Custom Image</label>
                                    <input type="text" class="form-control" id="custom_image<?php echo e($pelanggan->id); ?>" name="custom_image" value="<?php echo e($pelanggan->custom_image); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="a4<?php echo e($pelanggan->id); ?>">A4</label>
                                    <input type="text" class="form-control" id="a4<?php echo e($pelanggan->id); ?>" name="a4" value="<?php echo e($pelanggan->a4); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="pet<?php echo e($pelanggan->id); ?>">Pet</label>
                                    <input type="text" class="form-control" id="pet<?php echo e($pelanggan->id); ?>" name="pet" value="<?php echo e($pelanggan->pet); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="lovers_flowers<?php echo e($pelanggan->id); ?>">Lovers Flowers</label>
                                    <input type="text" class="form-control" id="lovers_flowers<?php echo e($pelanggan->id); ?>" name="lovers_flowers" value="<?php echo e($pelanggan->lovers_flowers); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="shift<?php echo e($pelanggan->id); ?>">Shift</label>
                                    <select class="form-control" id="shift<?php echo e($pelanggan->id); ?>" name="shift">
                                        <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($shift->id); ?>" <?php echo e($pelanggan->shift_id == $shift->id ? 'selected' : ''); ?>><?php echo e($shift->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="keterangan<?php echo e($pelanggan->id); ?>">Keterangan</label>
                                    <input type="text" class="form-control" id="keterangan<?php echo e($pelanggan->id); ?>" name="keterangan" value="<?php echo e($pelanggan->keterangan); ?>">
                                </div>

                            </form>

                            <!-- Isi formulir lainnya sesuai kebutuhan -->
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" id="saveChangesBtn">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- /.table-stats -->
    </div>
</div>
<!-- End of Modal Hapus -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LILA\sidang progres\snapoo\snapoo\resources\views/admin/pelanggan/pelanggan.blade.php ENDPATH**/ ?>