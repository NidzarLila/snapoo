<footer class="site-footer">
    <div class="footer-inner bg-white">
        <div class="row">
            <div class="col-sm-6">
                 &copy; 
            </div>
            <div class="col-sm-6 text-right">
                 <a href="#"></a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\LILA\sidang progres\snapoo\snapoo\resources\views/layouts/footer.blade.php ENDPATH**/ ?>