
<?php $__env->startSection('contents'); ?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <?php if(session()->has('pesan')): ?>
            <!-- Tampilkan pesan session dalam bentuk Toastr saat dokumen dimuat -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Panggil metode Toastr
                    toastr.success("<?php echo e(session('pesan')); ?>");
                });
            </script>
            <?php endif; ?>
            <?php if(session()->has('hapus')): ?>
            <!-- Tampilkan pesan session dalam bentuk Toastr saat dokumen dimuat -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Panggil metode Toastr
                    toastr.warning("<?php echo e(session('hapus')); ?>");
                });
            </script>
            <?php endif; ?>
            <strong class="card-title">Data Reservasi</strong>
            <div class="col-auto">
                <a href="<?php echo e(url('services/tambah')); ?>" class="btn btn-primary my-3">Tambah Data Services Extra</a>
                <a href="/pelanggan/exportexcel" class="btn btn-primary my-3" target="_blank">Download File Excel</a>
                <a href="/pelanggan/importexcel" class="btn btn-secondary my-3" data-toggle="modal" data-target="#exampleModal">Upload Data Pelanggan</a>
                <a href="/pelanggan/exportpdf" class="btn btn-info my-3" target="_blank">Download File PDF</a>
            </div>
        </div>

        <div class="table-responsive">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Email</th>
                        <th>No. Telepon</th>
                        <th>Alamat</th>
                        <th>Tanggal Reservasi</th>
                        <th>Waktu Reservasi</th>
                        <th>Total</th>
                        <th>Nama Paket</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="serial"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($reservasi->nama); ?></td>
                        <td><?php echo e($reservasi->email); ?></td>
                        <td><?php echo e($reservasi->no_hp); ?></td>
                        <td><?php echo e($reservasi->alamat); ?></td>
                        <td><?php echo e($reservasi->tanggal); ?></td>
                        <td><?php echo e($reservasi->waktu); ?></td>
                        <td><?php echo e($reservasi->subtotal); ?></td>
                        <td><?php echo e($reservasi->nama_paket); ?></td>
                        <td><?php echo e($reservasi->status); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="/reservasi/edit/<?php echo e($reservasi->id_reservasi); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#hapusModal<?php echo e($reservasi->id_reservasi); ?>"><i class="fa fa-trash-o"></i></a>
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#detailModal<?php echo e($reservasi->id_reservasi); ?>"><i class="fa fa-eye"></i></button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div> <!-- /.table-stats -->
    </div>
</div>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detailModal<?php echo e($reservasi->id_reservasi); ?>" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel<?php echo e($reservasi->id_reservasi); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel<?php echo e($reservasi->id_reservasi); ?>">Detail Reservasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Nama Lengkap: <?php echo e($reservasi->nama); ?></p>
                <p>Email: <?php echo e($reservasi->email); ?></p>
                <p>No. Telepon: <?php echo e($reservasi->no_hp); ?></p>
                <p>Alamat: <?php echo e($reservasi->alamat); ?></p>
                <p>Tanggal Reservasi: <?php echo e($reservasi->tanggal); ?></p>
                <p>Waktu Reservasi: <?php echo e($reservasi->waktu); ?></p>
                <p>Total: <?php echo e($reservasi->subtotal); ?></p>
                <p>Nama Paket: <?php echo e($reservasi->nama_paket); ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<div class="modal fade" id="hapusModal<?php echo e($reservasi->id_reservasi); ?>" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel<?php echo e($reservasi->id_reservasi); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusModalLabel<?php echo e($reservasi->id_reservasi); ?>">Konfirmasi Hapus Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus data ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <!-- Link untuk menghapus data -->
                <a href="<?php echo e(url('reservasi/hapus/' . $reservasi->id_reservasi)); ?>" class="btn btn-danger">Ya, Hapus</a>
            </div>
        </div>
    </div>
</div>

</tr>


</tbody>
</table>
</div> <!-- /.table-stats -->
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LILA\snapoo\resources\views/admin/reservasi/index.blade.php ENDPATH**/ ?>