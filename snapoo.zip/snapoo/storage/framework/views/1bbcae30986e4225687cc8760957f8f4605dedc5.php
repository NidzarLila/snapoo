
<?php $__env->startSection('contents'); ?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
        <?php if(session()->has('pesan')): ?>
            <!-- Tampilkan pesan session dalam bentuk Toastr saat dokumen dimuat -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Panggil metode Toastr
                    toastr.success("<?php echo e(session('pesan')); ?>");
                });
            </script>
            <?php endif; ?>
            <?php if(session()->has('hapus')): ?>
            <!-- Tampilkan pesan session dalam bentuk Toastr saat dokumen dimuat -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Panggil metode Toastr
                    toastr.warning("<?php echo e(session('hapus')); ?>");
                });
            </script>
            <?php endif; ?>
            <strong class="card-title">Data Pelanggan</strong>
            <div class="col-auto">
                <a href="<?php echo e(url('services/tambah')); ?>" class="btn btn-primary my-3">Tambah Data Services Extra</a>
                <a href="/pelanggan/exportexcel" class="btn btn-primary my-3" target="_blank">Download File Excel</a>
                <a href="/pelanggan/importexcel" class="btn btn-secondary my-3" data-toggle="modal" data-target="#exampleModal">Upload Data Pelanggan</a>
                <a href="/pelanggan/exportpdf" class="btn btn-info my-3" target="_blank">Download File PDF</a>
            </div>
            <!-- <div class="row">
                <div class="col-12">
                    <a href="/pelanggan/create" class="bi bi-plus blue-color float-right"></a>
                </div>
            </div> -->
        </div>
        <!-- <div class="card-header">
            <strong class="card-title">Data Produk</strong>
        </div>
        <div class="table-stats order-table ov-h">
            <a href="<?php echo e(url('produk/tambah')); ?>" class="btn btn-primary">Tambah Data</a> -->
        <table class="table ">
            <thead>
                <tr>
                    <th class="serial">No</th>
                    <th class="avatar">Nama Services</th>
                    <th>Keterangan</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="serial"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($service->nama_service); ?></td>
                    <td><?php echo e($service->keterangan); ?></td>
                    <td><?php echo e($service->harga); ?></td>
                    <td>
                        <a href="<?php echo e(url('services/edit/' . $service->id_services)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                           <!-- Link untuk membuka modal -->
                           <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#hapusModal<?php echo e($service->id_services); ?>">
                            <i class="fa fa-trash-o"></i>
                        </a>
                    </td>
                </tr>
                 <!-- Modal konfirmasi -->
                 <div class="modal fade" id="hapusModal<?php echo e($service->id_services); ?>" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel<?php echo e($service->id_services); ?>" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="hapusModalLabel<?php echo e($service->id_services); ?>">Konfirmasi Hapus Data</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Apakah Anda yakin ingin menghapus data ini?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <!-- Link untuk menghapus data -->
                                    <a href="<?php echo e(url('services/hapus/' . $service->id_services)); ?>" class="btn btn-danger">Ya, Hapus</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </tbody>
        </table>
    </div> <!-- /.table-stats -->
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LILA\sidang progres\snapoo\snapoo\resources\views/admin/services/index.blade.php ENDPATH**/ ?>