

<?php $__env->startSection('contents'); ?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <?php if(session()->has('pesan')): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    toastr.success("<?php echo e(session('pesan')); ?>");
                });
            </script>
            <?php endif; ?>
            <?php if(session()->has('hapus')): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    toastr.warning("<?php echo e(session('hapus')); ?>");
                });
            </script>
            <?php endif; ?>

            <strong class="card-title">Data Pelanggan</strong>
            <div class="col-auto">
                <a href="<?php echo e(url('produk/tambah')); ?>" class="btn btn-primary my-3">Tambah Data Produk</a>
                <a href="/pelanggan/exportexcel" class="btn btn-primary my-3" target="_blank">Download File Excel</a>
                <a href="/pelanggan/importexcel" class="btn btn-secondary my-3" data-toggle="modal" data-target="#exampleModal">Upload Data Pelanggan</a>
                <a href="/pelanggan/exportpdf" class="btn btn-info my-3" target="_blank">Download File PDF</a>
            </div>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th class="serial">No</th>
                    <th class="avatar">Paket</th>
                    <th>Keterangan</th>
                    <th>Harga</th>
                    <th>Gambar</th>
                    <th>Kuota</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($row->nama_paket); ?></td>
                    <td><?php echo e($row->deskripsi); ?></td>
                    <td><?php echo e($row->harga); ?></td>
                    <td><img src="<?php echo e(asset('images/' . $row->gambar)); ?>" width="100px"></td>
                    <td><?php echo e($row->slot); ?></td>
                    <td>
                        <a href="<?php echo e(url('produk/edit/' . $row->id_produk)); ?>" class="btn btn-warning" data-toggle="modal" data-target="#editModal<?php echo e($row->id_produk); ?>">
                            <i class="fa fa-edit"></i>
                        </a>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#hapusModal<?php echo e($row->id_produk); ?>">
                            <i class="fa fa-trash-o"></i>
                        </a>
                    </td>
                </tr>

                <!-- Modal edit -->
                <div class="modal fade" id="editModal<?php echo e($row->id_produk); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?php echo e($row->id_produk); ?>" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="<?php echo e(url('produk/' . $row->id_produk)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel<?php echo e($row->id_produk); ?>">Edit Produk</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="nama_paket">Nama Paket:</label>
                                        <input type="text" class="form-control" id="nama_paket" name="nama_paket" value="<?php echo e($row->nama_paket); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="deskripsi">Deskripsi:</label>
                                        <textarea class="form-control" id="deskripsi" name="deskripsi"><?php echo e($row->deskripsi); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="harga">Harga:</label>
                                        <input type="text" class="form-control" id="harga" name="harga" value="<?php echo e($row->harga); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="gambar">Gambar:</label>
                                        <input type="file" class="form-control-file" id="gambar" name="gambar">
                                        <img src="<?php echo e(asset('images/' . $row->gambar)); ?>" alt="Gambar Produk" class="img-fluid mb-2" style="max-width: 200px;">
                                    </div>
                                    <div class="form-group">
                                        <label for="slot">Kuota:</label>
                                        <input type="text" class="form-control" id="slot" name="slot" value="<?php echo e($row->slot); ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Modal edit -->

                <!-- Modal konfirmasi -->
                <div class="modal fade" id="hapusModal<?php echo e($row->id_produk); ?>" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel<?php echo e($row->id_produk); ?>" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="hapusModalLabel<?php echo e($row->id_produk); ?>">Konfirmasi Hapus Data</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                Apakah Anda yakin ingin menghapus data ini?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                <a href="<?php echo e(url('produk/hapus/' . $row->id_produk)); ?>" class="btn btn-danger">Ya, Hapus</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Modal konfirmasi -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div> <!-- /.table-stats -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PKUSOLO\Documents\snapoo\snapoo\resources\views/admin/produk/index.blade.php ENDPATH**/ ?>