<!doctype html>
<html lang="en">

<head>
    <title>Login 10</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('login/css/style.css')); ?>">
</head>

<body class="img js-fullheight" style="background-image: url(<?php echo e(asset('login/images/bg.jpg')); ?>);">
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                <div class="col-md-6 text-center mb-5">
                    <h2 class="heading-section">Login</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="login-wrap p-0">
                        <h3 class="mb-4 text-center">Have an account?</h3>
                        <form action="<?php echo e(url('proses_login')); ?>" method="POST" class="signin-form">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <?php $__errorArgs = ['login_gagal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <span class="alert-inner--icon"><i class="ni ni-like-2"></i></span>
                                    <span class="alert-inner--text"><strong>Warning!</strong> <?php echo e($message); ?></span>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="text" class="form-control" name="username" placeholder="Username" required>
                                <?php if($errors->has('username')): ?>
                                <span class="error"><?php echo e($errors->first('username')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input id="password-field" type="password" name="password" class="form-control" placeholder="Password" required>
                                <?php if($errors->has('password')): ?>
                                <span class="error"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                                <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="form-control btn btn-primary submit px-3">Sign In</button>
                            </div>
                            <div class="form-group d-md-flex">
                                <div class="w-50">

                                </div>

                            </div>
                        </form>

                    </div>
                    <div class="card-footer text-center">
                        <div class="small">
                            <a href="<?php echo e(url('register1')); ?>">Belum Punya Akun? Daftar!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="<?php echo e(asset('login/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('login/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\laragon\www\LILA\sidang progres\snapoo\snapoo\resources\views/login.blade.php ENDPATH**/ ?>