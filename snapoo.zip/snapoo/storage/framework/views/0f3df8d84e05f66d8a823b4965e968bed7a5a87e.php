<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total {
            text-align: right;
            font-weight: bold;
        }
        .total-value {
            text-align: right;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Laporan Penjualan</h1>
        <p>Dari: <?php echo e($tanggal_awal); ?> Sampai: <?php echo e($tanggal_akhir); ?></p>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID Reservasi</th>
                <th>Tanggal</th>
                <th>Nama Pelanggan</th>
                <th>Produk</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $totalPenjualan = 0; ?>
            <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id_reservasi); ?></td>
                <td><?php echo e($item->tanggal); ?></td>
                <td><?php echo e($item->nama); ?></td>
                <td><?php echo e($item->nama_paket); ?></td>
                <td><?php echo e('Rp ' . number_format($item->subtotal, 0, ',', '.')); ?></td>
                <td><?php echo e($item->status); ?></td>
                <?php $totalPenjualan += $item->subtotal; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4" class="total">Total Penjualan:</td>
                <td class="total-value"><?php echo e('Rp ' . number_format($totalPenjualan, 0, ',', '.')); ?></td>
                <td></td>
            </tr>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\Administrator\Downloads\snapoo\snapoo\resources\views/admin/laporan/pdf.blade.php ENDPATH**/ ?>