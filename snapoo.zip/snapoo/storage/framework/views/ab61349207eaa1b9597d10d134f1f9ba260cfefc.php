

<?php $__env->startSection('contents'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                    <strong class="card-title">Laporan Penjualan </strong>
                   
                    <div class="row">
                       
                            <form action="<?php echo e(route('laporan.index')); ?>" method="GET">
                                <div class="form-group">
                                    <label for="tanggal_awal">Tanggal Awal:</label>
                                    <input type="date" class="form-control" id="tanggal_awal" name="tanggal_awal" required>
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_akhir">Tanggal Akhir:</label>
                                    <input type="date" class="form-control" id="tanggal_akhir" name="tanggal_akhir" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </form>
                        </div>
                      
                            <form action="<?php echo e(route('laporan.export-pdf')); ?>" method="GET" class="text-right">
                                <input type="hidden" name="tanggal_awal" value="<?php echo e(request('tanggal_awal')); ?>">
                                <input type="hidden" name="tanggal_akhir" value="<?php echo e(request('tanggal_akhir')); ?>">
                                <button type="submit" class="btn btn-success">Ekspor ke PDF</button>
                            </form>
                        </div>
                    </div>

                    <?php if($laporan->isNotEmpty()): ?>
                    <?php
                    $totalPendapatan = 0;
                    ?>
                    <div class="table-responsive">


                        <table id="example" class="table table-striped table-hover table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="serial">ID Reservasi</th>
                                    <th class="avatar">Tanggal</th>
                                    <th class="avatar">Nama Pelanggan</th>
                                    <th class="avatar">Produk</th>
                                    <th class="avatar">Total</th>
                                    <th class="avatar">Status</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id_reservasi); ?></td>
                                    <td><?php echo e($item->tanggal); ?></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->nama_paket); ?></td>
                                    <td><?php echo e('Rp ' . number_format($item->subtotal, 0, ',', '.')); ?></td>
                                    <td><?php echo e($item->status); ?></td>
                                    
                                </tr>
                                <?php
                                $totalPendapatan += $item->subtotal;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- <tr>
                                    <td colspan="4" style="text-align: right;"><strong>Total Pendapatan:</strong></td>
                                    <td><strong><?php echo e('Rp ' . number_format($totalPendapatan, 0, ',', '.')); ?></strong></td>
                                    
                                </tr> -->
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p>Silakan pilih tanggal untuk melihat laporan.</p>
                    <?php endif; ?>
                </div>
            </div> <!-- /.card -->
        </div> <!-- /.col-lg-12 -->
    </div>

</div>



<!-- End Modal Tambah Data -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Downloads\snapoo\snapoo\resources\views/admin/laporan/laporanpenjualan.blade.php ENDPATH**/ ?>